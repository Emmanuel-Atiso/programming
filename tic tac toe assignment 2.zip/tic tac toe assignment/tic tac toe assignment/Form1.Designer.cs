﻿namespace tic_tac_toe_assignment
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            panel1 = new Panel();
            btnTac9 = new Button();
            btnTac8 = new Button();
            btnTac6 = new Button();
            btnTac5 = new Button();
            btnTac4 = new Button();
            btnTac3 = new Button();
            btnTac2 = new Button();
            btnTac7 = new Button();
            btnTac1 = new Button();
            btnExit = new Button();
            btnReset = new Button();
            btnNewGame = new Button();
            txtPlayerX = new Label();
            txtPlayerO = new Label();
            lblPlayerX = new Label();
            lblPlayerO = new Label();
            panel1.SuspendLayout();
            SuspendLayout();
            // 
            // panel1
            // 
            panel1.BorderStyle = BorderStyle.Fixed3D;
            panel1.Controls.Add(btnTac9);
            panel1.Controls.Add(btnTac8);
            panel1.Controls.Add(btnTac6);
            panel1.Controls.Add(btnTac5);
            panel1.Controls.Add(btnTac4);
            panel1.Controls.Add(btnTac3);
            panel1.Controls.Add(btnTac2);
            panel1.Controls.Add(btnTac7);
            panel1.Controls.Add(btnTac1);
            panel1.Location = new Point(227, 129);
            panel1.Name = "panel1";
            panel1.Size = new Size(767, 661);
            panel1.TabIndex = 0;
            // 
            // btnTac9
            // 
            btnTac9.BackColor = Color.White;
            btnTac9.Font = new Font("Microsoft Sans Serif", 90.75F, FontStyle.Regular, GraphicsUnit.Point);
            btnTac9.Location = new Point(530, 429);
            btnTac9.Name = "btnTac9";
            btnTac9.Size = new Size(215, 217);
            btnTac9.TabIndex = 9;
            btnTac9.UseVisualStyleBackColor = false;
            btnTac9.Click += btnTac9_Click;
            // 
            // btnTac8
            // 
            btnTac8.BackColor = Color.White;
            btnTac8.Font = new Font("Microsoft Sans Serif", 90.75F, FontStyle.Regular, GraphicsUnit.Point);
            btnTac8.Location = new Point(281, 429);
            btnTac8.Name = "btnTac8";
            btnTac8.Size = new Size(233, 217);
            btnTac8.TabIndex = 8;
            btnTac8.UseVisualStyleBackColor = false;
            btnTac8.Click += btnTac8_Click;
            // 
            // btnTac6
            // 
            btnTac6.BackColor = Color.White;
            btnTac6.Font = new Font("Microsoft Sans Serif", 90.75F, FontStyle.Regular, GraphicsUnit.Point);
            btnTac6.Location = new Point(530, 213);
            btnTac6.Name = "btnTac6";
            btnTac6.Size = new Size(215, 197);
            btnTac6.TabIndex = 7;
            btnTac6.UseVisualStyleBackColor = false;
            btnTac6.Click += btnTac6_Click;
            // 
            // btnTac5
            // 
            btnTac5.BackColor = Color.White;
            btnTac5.Font = new Font("Microsoft Sans Serif", 90.75F, FontStyle.Regular, GraphicsUnit.Point);
            btnTac5.Location = new Point(281, 213);
            btnTac5.Name = "btnTac5";
            btnTac5.Size = new Size(233, 197);
            btnTac5.TabIndex = 6;
            btnTac5.UseVisualStyleBackColor = false;
            btnTac5.Click += btnTac5_Click;
            // 
            // btnTac4
            // 
            btnTac4.BackColor = Color.White;
            btnTac4.Font = new Font("Microsoft Sans Serif", 90.75F, FontStyle.Regular, GraphicsUnit.Point);
            btnTac4.Location = new Point(29, 213);
            btnTac4.Name = "btnTac4";
            btnTac4.Size = new Size(233, 197);
            btnTac4.TabIndex = 5;
            btnTac4.UseVisualStyleBackColor = false;
            btnTac4.Click += btnTac4_Click;
            // 
            // btnTac3
            // 
            btnTac3.BackColor = Color.White;
            btnTac3.Font = new Font("Microsoft Sans Serif", 90.75F, FontStyle.Regular, GraphicsUnit.Point);
            btnTac3.Location = new Point(530, 4);
            btnTac3.Name = "btnTac3";
            btnTac3.Size = new Size(215, 192);
            btnTac3.TabIndex = 4;
            btnTac3.UseVisualStyleBackColor = false;
            btnTac3.Click += btnTac3_Click;
            // 
            // btnTac2
            // 
            btnTac2.BackColor = Color.White;
            btnTac2.Font = new Font("Microsoft Sans Serif", 90.75F, FontStyle.Regular, GraphicsUnit.Point);
            btnTac2.Location = new Point(281, 4);
            btnTac2.Name = "btnTac2";
            btnTac2.Size = new Size(233, 191);
            btnTac2.TabIndex = 3;
            btnTac2.UseVisualStyleBackColor = false;
            btnTac2.Click += btnTac2_Click;
            // 
            // btnTac7
            // 
            btnTac7.BackColor = Color.White;
            btnTac7.Font = new Font("Microsoft Sans Serif", 90.75F, FontStyle.Regular, GraphicsUnit.Point);
            btnTac7.Location = new Point(29, 429);
            btnTac7.Name = "btnTac7";
            btnTac7.Size = new Size(233, 217);
            btnTac7.TabIndex = 8;
            btnTac7.UseVisualStyleBackColor = false;
            btnTac7.Click += btnTac7_Click;
            // 
            // btnTac1
            // 
            btnTac1.BackColor = Color.White;
            btnTac1.Font = new Font("Microsoft Sans Serif", 90.75F, FontStyle.Regular, GraphicsUnit.Point);
            btnTac1.Location = new Point(29, 4);
            btnTac1.Name = "btnTac1";
            btnTac1.Size = new Size(233, 191);
            btnTac1.TabIndex = 2;
            btnTac1.UseVisualStyleBackColor = false;
            btnTac1.Click += btnTac1_Click;
            // 
            // btnExit
            // 
            btnExit.Location = new Point(789, 795);
            btnExit.Name = "btnExit";
            btnExit.Size = new Size(171, 69);
            btnExit.TabIndex = 9;
            btnExit.Text = "Exit";
            btnExit.UseVisualStyleBackColor = true;
            btnExit.Click += btnExit_Click_1;
            // 
            // btnReset
            // 
            btnReset.Location = new Point(290, 796);
            btnReset.Name = "btnReset";
            btnReset.Size = new Size(171, 70);
            btnReset.TabIndex = 9;
            btnReset.Text = "Reset";
            btnReset.UseVisualStyleBackColor = true;
            btnReset.Click += btnReset_Click;
            // 
            // btnNewGame
            // 
            btnNewGame.Location = new Point(542, 795);
            btnNewGame.Name = "btnNewGame";
            btnNewGame.Size = new Size(171, 70);
            btnNewGame.TabIndex = 8;
            btnNewGame.Text = "New Game";
            btnNewGame.UseVisualStyleBackColor = true;
            btnNewGame.Click += btnNewGame_Click;
            // 
            // txtPlayerX
            // 
            txtPlayerX.AutoSize = true;
            txtPlayerX.Font = new Font("Segoe UI", 28F, FontStyle.Regular, GraphicsUnit.Point);
            txtPlayerX.ForeColor = SystemColors.ButtonHighlight;
            txtPlayerX.Location = new Point(29, 12);
            txtPlayerX.Name = "txtPlayerX";
            txtPlayerX.Size = new Size(240, 74);
            txtPlayerX.TabIndex = 9;
            txtPlayerX.Text = "Player X:";
            // 
            // txtPlayerO
            // 
            txtPlayerO.AutoSize = true;
            txtPlayerO.Font = new Font("Segoe UI", 28F, FontStyle.Regular, GraphicsUnit.Point);
            txtPlayerO.ForeColor = SystemColors.ButtonFace;
            txtPlayerO.Location = new Point(579, 18);
            txtPlayerO.Name = "txtPlayerO";
            txtPlayerO.Size = new Size(249, 74);
            txtPlayerO.TabIndex = 10;
            txtPlayerO.Text = "Player O:";
            // 
            // lblPlayerX
            // 
            lblPlayerX.BackColor = SystemColors.ButtonHighlight;
            lblPlayerX.BorderStyle = BorderStyle.Fixed3D;
            lblPlayerX.Font = new Font("Segoe UI", 28F, FontStyle.Regular, GraphicsUnit.Point);
            lblPlayerX.Location = new Point(275, 18);
            lblPlayerX.Name = "lblPlayerX";
            lblPlayerX.Size = new Size(273, 75);
            lblPlayerX.TabIndex = 11;
            lblPlayerX.Text = "0";
            lblPlayerX.TextAlign = ContentAlignment.TopCenter;
            // 
            // lblPlayerO
            // 
            lblPlayerO.BackColor = SystemColors.ButtonHighlight;
            lblPlayerO.BorderStyle = BorderStyle.Fixed3D;
            lblPlayerO.Font = new Font("Segoe UI", 28F, FontStyle.Regular, GraphicsUnit.Point);
            lblPlayerO.Location = new Point(825, 18);
            lblPlayerO.Name = "lblPlayerO";
            lblPlayerO.Size = new Size(283, 75);
            lblPlayerO.TabIndex = 12;
            lblPlayerO.Text = "0";
            lblPlayerO.TextAlign = ContentAlignment.TopCenter;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(10F, 25F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.IndianRed;
            ClientSize = new Size(1120, 935);
            Controls.Add(btnExit);
            Controls.Add(lblPlayerO);
            Controls.Add(lblPlayerX);
            Controls.Add(txtPlayerO);
            Controls.Add(btnReset);
            Controls.Add(txtPlayerX);
            Controls.Add(panel1);
            Controls.Add(btnNewGame);
            FormBorderStyle = FormBorderStyle.FixedSingle;
         
            MaximizeBox = false;
            MinimizeBox = false;
            Name = "Form1";
            Text = "Tic Tac Toe game";
            panel1.ResumeLayout(false);
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Panel panel1;
        private Button btnTac3;
        private Button btnTac2;
        private Button btnTac1;
        private Button btnTac9;
        private Button btnTac8;
        private Button btnTac6;
        private Button btnTac5;
        private Button btnTac4;
        private Button btnTac7;
        private Button btnExit;
        private Button btnReset;
        private Button btnNewGame;
        private Label txtPlayerX;
        private Label txtPlayerO;
        private Label lblPlayerX;
        private Label lblPlayerO;
    }
}