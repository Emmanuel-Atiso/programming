using Microsoft.VisualBasic.ApplicationServices;

namespace tic_tac_toe_assignment
{
   
    public partial class Form1 : Form
    {
      
        Player playerX;
        Player playerO;

        public Boolean checker;
        public int plusone;
        List<Button> buttons;
        List<Button> newGameButtons;

      
        private bool IsDraw()
        {
            foreach (var button in buttons)
            {
                if (string.IsNullOrEmpty(button.Text))
                {
                    return false; // At least one button is empty, the game is not a draw
                }
            }

            return true; // All buttons are filled, and no player has won
        }

        void Enable_false()
        {
            foreach (var button in buttons)
            {
                button.Enabled = false;
            }
        }
        //=======================================================
        void UpdateScoreAndDisableButton()
        {
            plusone = int.Parse(lblPlayerX.Text);
            lblPlayerX.Text = Convert.ToString(plusone + 1);
            Enable_false();
            ResetGame();
        }

        void UpdateScoreAndDisableButton1()
        {
            plusone = int.Parse(lblPlayerO.Text);
            lblPlayerO.Text = Convert.ToString(plusone + 1);
            Enable_false();
            ResetGame();
        }
        //=====================================================
        private void HandleButtonClick(Button button)
        {
            if (checker == false)
            {
                button.Text = playerX.Symbol.ToString();
                checker = true;
            }
            else
            {
                button.Text = playerO.Symbol.ToString();
                checker = false;
            }
            score();
            button.Enabled = false;

            if (IsDraw())
            {
                MessageBox.Show("The game is a draw!");
                ResetGame();
            }
        }
        //=======================================================
        void score()
        {
            if (btnTac1.Text == "X" && btnTac2.Text == "X" && btnTac3.Text == "X")
            {
                btnTac1.BackColor = Color.BlueViolet;
                btnTac2.BackColor = Color.BlueViolet;
                btnTac3.BackColor = Color.BlueViolet;

                MessageBox.Show("The WINNER is Player X");
                UpdateScoreAndDisableButton();
            }

            if (btnTac1.Text == "X" && btnTac4.Text == "X" && btnTac7.Text == "X")
            {
                btnTac1.BackColor = Color.Red;
                btnTac4.BackColor = Color.Red;
                btnTac7.BackColor = Color.Red;

                MessageBox.Show("The WINNER is Player X");
                UpdateScoreAndDisableButton();

            }

            if (btnTac1.Text == "X" && btnTac5.Text == "X" && btnTac9.Text == "X")
            {
                btnTac1.BackColor = Color.YellowGreen;
                btnTac5.BackColor = Color.YellowGreen;
                btnTac9.BackColor = Color.YellowGreen;


                MessageBox.Show("The WINNER is Player X");
                UpdateScoreAndDisableButton();


            }
            if (btnTac3.Text == "X" && btnTac5.Text == "X" && btnTac7.Text == "X")
            {
                btnTac3.BackColor = Color.Crimson;
                btnTac5.BackColor = Color.Crimson;
                btnTac7.BackColor = Color.Crimson;

                MessageBox.Show("The WINNER is Player X");
                UpdateScoreAndDisableButton();

            }

            if (btnTac2.Text == "X" && btnTac5.Text == "X" && btnTac8.Text == "X")
            {
                btnTac2.BackColor = Color.AliceBlue;
                btnTac5.BackColor = Color.AliceBlue;
                btnTac8.BackColor = Color.AliceBlue;


                MessageBox.Show("The WINNER is Player X");
                UpdateScoreAndDisableButton();

            }

            if (btnTac3.Text == "X" && btnTac6.Text == "X" && btnTac9.Text == "X")
            {
                btnTac3.BackColor = Color.Pink;
                btnTac6.BackColor = Color.Pink;
                btnTac9.BackColor = Color.Pink;


                MessageBox.Show("The WINNER is Player X");
                UpdateScoreAndDisableButton();

            }

            if (btnTac4.Text == "X" && btnTac5.Text == "X" && btnTac6.Text == "X")
            {
                btnTac4.BackColor = Color.Green;
                btnTac5.BackColor = Color.Green;
                btnTac6.BackColor = Color.Green;

                MessageBox.Show("The WINNER is Player X");
                UpdateScoreAndDisableButton();

            }

            if (btnTac7.Text == "X" && btnTac8.Text == "X" && btnTac9.Text == "X")
            {
                btnTac7.BackColor = Color.Aqua;
                btnTac8.BackColor = Color.Aqua;
                btnTac9.BackColor = Color.Aqua;

                MessageBox.Show("The WINNER is Player X");
                UpdateScoreAndDisableButton();
            }

            //=====================================================================================================
            //Code for Player O//

            if (btnTac1.Text == "O" && btnTac2.Text == "O" && btnTac3.Text == "O")
            {
                btnTac1.BackColor = Color.BlueViolet;
                btnTac2.BackColor = Color.BlueViolet;
                btnTac3.BackColor = Color.BlueViolet;

                MessageBox.Show("The WINNER is Player O");
                UpdateScoreAndDisableButton1();
            }

            if (btnTac1.Text == "O" && btnTac4.Text == "O" && btnTac7.Text == "O")
            {
                btnTac1.BackColor = Color.Red;
                btnTac4.BackColor = Color.Red;
                btnTac7.BackColor = Color.Red;

                MessageBox.Show("The WINNER is Player O");
                UpdateScoreAndDisableButton1();

            }

            if (btnTac1.Text == "O" && btnTac5.Text == "O" && btnTac9.Text == "O")
            {
                btnTac1.BackColor = Color.YellowGreen;
                btnTac5.BackColor = Color.YellowGreen;
                btnTac9.BackColor = Color.YellowGreen;

                MessageBox.Show("The WINNER is Player O");
                UpdateScoreAndDisableButton1();

            }
            if (btnTac3.Text == "O" && btnTac5.Text == "O" && btnTac7.Text == "O")
            {
                btnTac3.BackColor = Color.Crimson;
                btnTac5.BackColor = Color.Crimson;
                btnTac7.BackColor = Color.Crimson;

                MessageBox.Show("The WINNER is Player O");
                UpdateScoreAndDisableButton1();

            }
            if (btnTac2.Text == "O" && btnTac5.Text == "O" && btnTac8.Text == "O")
            {
                btnTac2.BackColor = Color.AliceBlue;
                btnTac5.BackColor = Color.AliceBlue;
                btnTac8.BackColor = Color.AliceBlue;

                MessageBox.Show("The WINNER is Player O");
                UpdateScoreAndDisableButton1();

            }

            if (btnTac3.Text == "O" && btnTac6.Text == "O" && btnTac9.Text == "O")
            {
                btnTac3.BackColor = Color.Pink;
                btnTac6.BackColor = Color.Pink;
                btnTac9.BackColor = Color.Pink;
                MessageBox.Show("The WINNER is Player O");
                UpdateScoreAndDisableButton1();

            }

            if (btnTac4.Text == "O" && btnTac5.Text == "O" && btnTac6.Text == "O")
            {
                btnTac4.BackColor = Color.Green;
                btnTac5.BackColor = Color.Green;
                btnTac6.BackColor = Color.Green;

                MessageBox.Show("The WINNER is Player O");
                UpdateScoreAndDisableButton1();

            }

            if (btnTac7.Text == "O" && btnTac8.Text == "O" && btnTac9.Text == "O")
            {
                btnTac7.BackColor = Color.Aqua;
                btnTac8.BackColor = Color.Aqua;
                btnTac9.BackColor = Color.Aqua;

                MessageBox.Show("The WINNER is Player O");
                UpdateScoreAndDisableButton1();

            }

        }
        //====================================================================================================================
        public Form1()
        {

            InitializeComponent();
            buttons = new List<Button> { btnTac1, btnTac2, btnTac3, btnTac4, btnTac5, btnTac6, btnTac7, btnTac8, btnTac9 };
            newGameButtons = new List<Button> { btnNewGame, btnReset };
            playerX = new Player("Player X", 'X');
            playerO = new Player("Player O", 'O');
        }
        private void btnTac1_Click(object sender, EventArgs e)
        {
            HandleButtonClick(btnTac1);
        }

        private void btnTac2_Click(object sender, EventArgs e)
        {
            HandleButtonClick(btnTac2);
        }

        private void btnTac3_Click(object sender, EventArgs e)
        {
            HandleButtonClick(btnTac3);
        }

        private void btnTac4_Click(object sender, EventArgs e)
        {
            HandleButtonClick(btnTac4);
        }

        private void btnTac5_Click(object sender, EventArgs e)
        {
            HandleButtonClick(btnTac5);
        }

        private void btnTac6_Click(object sender, EventArgs e)
        {
            HandleButtonClick(btnTac6);
        }

        private void btnTac7_Click(object sender, EventArgs e)
        {
            HandleButtonClick(btnTac7);
        }

        private void btnTac8_Click(object sender, EventArgs e)
        {
            HandleButtonClick(btnTac8);
        }

        private void btnTac9_Click(object sender, EventArgs e)
        {
            HandleButtonClick(btnTac9);

        }
        //===================================================================================================================
        void ResetBackColor()
        {
            btnTac1.BackColor = Color.WhiteSmoke;
            btnTac2.BackColor = Color.WhiteSmoke;
            btnTac3.BackColor = Color.WhiteSmoke;
            btnTac4.BackColor = Color.WhiteSmoke;
            btnTac5.BackColor = Color.WhiteSmoke;
            btnTac6.BackColor = Color.WhiteSmoke;
            btnTac7.BackColor = Color.WhiteSmoke;
            btnTac8.BackColor = Color.WhiteSmoke;
            btnTac9.BackColor = Color.WhiteSmoke;
        }

        private void btnNewGame_Click(object sender, EventArgs e)
        {
            foreach (var button in buttons)
            {
                button.Enabled = true;
                button.Text = "";
            }

            lblPlayerX.Text = "0";
            lblPlayerO.Text = "0";

            ResetBackColor();
        }

        private void btnReset_Click(object sender, EventArgs e)
        {
            foreach (var button in buttons)
            {
                button.Enabled = true;
                button.Text = "";
            }

            ResetBackColor();

        }

        private void btnExit_Click_1(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void ResetGame()
        {
            foreach (var button in buttons)
            {
                button.Enabled = true;
                button.Text = "";
            }

            ResetBackColor();
        }
        public class Player
        {
            public string Name { get; set; }
            public char Symbol { get; set; }

            public Player(string name, char symbol)
            {
                Name = name;
                Symbol = symbol;
            }
        }

    }
}